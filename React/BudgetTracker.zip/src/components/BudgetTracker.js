import React from "react";
import IncomeForm from "./IncomeForm";
import ExpenseForm from "./ExpenseForm";
import Summary from "./Summary";

const BudgetTracker = () => {
  return (
    <div>
      <div className="flex flex-col md:flex-row gap-8 mb-8">
        <IncomeForm />
        <ExpenseForm />
      </div>
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-3xl font-bold text-left">Summary</h2>
        <button
          className="px-4 py-2 border border-neutral-300 rounded-md bg-[#FAFAFA] hover:bg-gray-100 transition font-bold text-sm"
          data-testid="reset-btn"
        >
          Reset
        </button>
      </div>
      <Summary />
    </div>
  );
};

export default BudgetTracker;
