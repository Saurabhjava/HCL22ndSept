import React from "react";

const Summary = () => {
  return (
    <div data-testid="summary" className="flex flex-col md:flex-row gap-8">
      <div
        data-testid="total-income"
        className="flex-1 bg-white rounded-xl shadow p-6 min-w-[200px]"
      >
        <div className="text-gray-600 text-sm mb-2">Total Income</div>
        <div className="text-4xl font-bold text-[#18A149]">$100.00</div>
      </div>
      <div
        data-testid="total-expenses"
        className="flex-1 bg-white rounded-xl shadow p-6 min-w-[200px]"
      >
        <div className="text-gray-600 text-sm mb-2">Total Expenses</div>
        <div className="text-4xl font-bold text-[#D92D20]">$50.00</div>
      </div>
      <div
        data-testid="balance"
        className="flex-1 bg-white rounded-xl shadow p-6 min-w-[200px]"
      >
        <div className="text-gray-600 text-sm mb-2">Balance</div>
        <div className="text-4xl font-bold text-black">$50.00</div>
      </div>
    </div>
  );
};

export default Summary;
