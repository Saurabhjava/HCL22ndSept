import React from "react";
import { CircleMinus } from "lucide-react";

const ExpenseForm = () => {
  return (
    <form className="flex-1 bg-white rounded-xl shadow p-5 flex flex-col items-start gap-6 min-w-[320px]">
      <div className="flex flex-row space-x-3">
        <div className="bg-[#FEE4E2] text-[#D92D20] rounded-lg p-3">
          <CircleMinus size={24} />
        </div>
        <div>
          <div className="font-bold text-base">Add expense</div>
          <div className="text-neutral-500 text-sm">
            Create an expense manually
          </div>
        </div>
      </div>
      <div className="flex-1 flex w-full items-center bg-gray-100 rounded-lg border border-gray-200 px-3 py-2 mb-3">
        <span className="text-black mr-3 text-xl">$</span>
        <input
          className="flex-1 bg-transparent outline-none text-black placeholder-black text-sm"
          data-testid="expense-input"
          type="number"
          placeholder="Enter expense here"
          value={`200`}
        />
        <button
          className="ml-2 bg-black text-white px-4 py-2 rounded-lg text-sm hover:bg-gray-800 transition"
          data-testid="add-expense-btn"
          type="button"
        >
          Add
        </button>
      </div>
    </form>
  );
};

export default ExpenseForm;
